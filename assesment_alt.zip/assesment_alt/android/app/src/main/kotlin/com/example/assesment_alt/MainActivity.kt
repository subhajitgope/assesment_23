package com.example.assesment_alt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
